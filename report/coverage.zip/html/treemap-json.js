processTreeMapJson (  {"id":"Clover database Mon Dec 2 2013 16:47:14 CST0","name":"","data":{
    "$area":1512.0,"$color":72.22222,"title":
    " 1512 Elements, 72.2% Coverage"},"children":[{"id":"test641","name":
      "test","data":{"$area":15.0,"$color":86.666664,"title":
        "test 15 Elements, 86.7% Coverage"},"children":[{"id":
          "GPUtilities957","name":"GPUtilities","data":{"$area":15.0,
            "$color":86.666664,"path":"test/GPUtilities.html#GPUtilities",
            "title":"GPUtilities 15 Elements, 86.7% Coverage"},"children":[]}]},
    {"id":"utilities0","name":"utilities","data":{"$area":641.0,"$color":
        60.374416,"title":"utilities 641 Elements, 60.4% Coverage"},
      "children":[{"id":"Utilities0","name":"Utilities","data":{"$area":
            112.0,"$color":82.14286,"path":
            "utilities/Utilities.html#Utilities","title":
            "Utilities 112 Elements, 82.1% Coverage"},"children":[]},{"id":
          "TreePrinter112","name":"TreePrinter","data":{"$area":71.0,
            "$color":0.0,"path":"utilities/TreePrinter.html#TreePrinter",
            "title":"TreePrinter 71 Elements, 0% Coverage"},"children":[]},{
          "id":"Settings183","name":"Settings","data":{"$area":100.0,
            "$color":82.0,"path":"utilities/Settings.html#Settings","title":
            "Settings 100 Elements, 82% Coverage"},"children":[]},{"id":
          "NodeFactory283","name":"NodeFactory","data":{"$area":119.0,
            "$color":54.621853,"path":
            "utilities/NodeFactory.html#NodeFactory","title":
            "NodeFactory 119 Elements, 54.6% Coverage"},"children":[]},{"id":
          "GeneticOperators402","name":"GeneticOperators","data":{"$area":
            184.0,"$color":80.434784,"path":
            "utilities/GeneticOperators.html#GeneticOperators","title":
            "GeneticOperators 184 Elements, 80.4% Coverage"},"children":[]},{
          "id":"BPTreeMain586","name":"BPTreeMain","data":{"$area":53.0,
            "$color":0.0,"path":"utilities/BPTreeMain.html#BPTreeMain",
            "title":"BPTreeMain 53 Elements, 0% Coverage"},"children":[]},{
          "id":"Node639","name":"Node","data":{"$area":2.0,"$color":0.0,
            "path":"utilities/BPTreeMain.html#Node","title":
            "Node 2 Elements, 0% Coverage"},"children":[]}]},{"id":
      "data972","name":"data","data":{"$area":717.0,"$color":81.8689,"title":
        "data 717 Elements, 81.9% Coverage"},"children":[{"id":"Tree972",
          "name":"Tree","data":{"$area":168.0,"$color":75.59524,"path":
            "data/Tree.html#Tree","title":
            "Tree 168 Elements, 75.6% Coverage"},"children":[]},{"id":
          "TrainingData1140","name":"TrainingData","data":{"$area":68.0,
            "$color":91.17647,"path":"data/TrainingData.html#TrainingData",
            "title":"TrainingData 68 Elements, 91.2% Coverage"},"children":[]},
        {"id":"OutputData1208","name":"OutputData","data":{"$area":141.0,
            "$color":95.03546,"path":"data/OutputData.html#OutputData",
            "title":"OutputData 141 Elements, 95% Coverage"},"children":[]},{
          "id":"OperatorNode1349","name":"OperatorNode","data":{"$area":
            53.0,"$color":79.245285,"path":
            "data/OperatorNode.html#OperatorNode","title":
            "OperatorNode 53 Elements, 79.2% Coverage"},"children":[]},{"id":
          "OperandNode1402","name":"OperandNode","data":{"$area":30.0,
            "$color":70.0,"path":"data/OperandNode.html#OperandNode","title":
            "OperandNode 30 Elements, 70% Coverage"},"children":[]},{"id":
          "Node1432","name":"Node","data":{"$area":160.0,"$color":75.625,
            "path":"data/Node.html#Node","title":
            "Node 160 Elements, 75.6% Coverage"},"children":[]},{"id":
          "GeneticProgrammingTree1592","name":"GeneticProgrammingTree",
          "data":{"$area":97.0,"$color":82.47423,"path":
            "data/GeneticProgrammingTree.html#GeneticProgrammingTree",
            "title":"GeneticProgrammingTree 97 Elements, 82.5% Coverage"},
          "children":[]}]},{"id":"default-pkg1689","name":"default-pkg",
      "data":{"$area":139.0,"$color":75.53957,"title":
        "default-pkg 139 Elements, 75.5% Coverage"},"children":[{"id":
          "GeneticProgrammingMain1689","name":"GeneticProgrammingMain",
          "data":{"$area":139.0,"$color":75.53957,"path":
            "default-pkg/GeneticProgrammingMain.html#GeneticProgrammingMain",
            "title":"GeneticProgrammingMain 139 Elements, 75.5% Coverage"},
          "children":[]}]}]}

 ); 