processTreeMapDashJson (  {"id":"Clover database Mon Dec 2 2013 16:47:14 CST0","name":"","data":{
    "$area":1512.0,"$color":72.22222,"title":
    " 1512 Elements, 72.2% Coverage"},"children":[{"id":"test641","name":
      "test","data":{"$area":15.0,"$color":86.666664,"title":
        "test 15 Elements, 86.7% Coverage"},"children":[]},{"id":
      "utilities0","name":"utilities","data":{"$area":641.0,"$color":
        60.374416,"title":"utilities 641 Elements, 60.4% Coverage"},
      "children":[]},{"id":"data972","name":"data","data":{"$area":717.0,
        "$color":81.8689,"title":"data 717 Elements, 81.9% Coverage"},
      "children":[]},{"id":"default-pkg1689","name":"default-pkg","data":{
        "$area":139.0,"$color":75.53957,"title":
        "default-pkg 139 Elements, 75.5% Coverage"},"children":[]}]}

 ); 