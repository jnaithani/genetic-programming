var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":47,"id":876,"methods":[{"el":27,"sc":5,"sl":14},{"el":46,"sc":5,"sl":29}],"name":"SettingsTest","sl":12}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_13":{"methods":[{"sl":29}],"name":"testPrintAllSettings","pass":true,"statements":[{"sl":31},{"sl":33},{"sl":34},{"sl":36},{"sl":38},{"sl":39},{"sl":40}]},"test_4":{"methods":[{"sl":14}],"name":"testPrintMaxNodesSetting","pass":true,"statements":[{"sl":16},{"sl":18},{"sl":19},{"sl":20},{"sl":21},{"sl":22}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [4], [], [4], [], [4], [4], [4], [4], [4], [], [], [], [], [], [], [13], [], [13], [], [13], [13], [], [13], [], [13], [13], [13], [], [], [], [], [], [], []]
